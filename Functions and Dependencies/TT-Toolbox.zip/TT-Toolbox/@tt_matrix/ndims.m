function d = ndims(tt)
%Number of dimensions of a TT-matrix
%   [D]=NDIMS(TT)
d=tt.tt.d;
return
end
