function [y]=multifuncrs2(X, funs, eps, varargin)
% The multifuncrs functionality is now embedded into amen_cross

warning('The multifuncrs functionality is now embedded into amen_cross');
y = amen_cross(X, funs, eps, varargin);

end
