function display(t)
%Command window display of a QTT-Tucker
disp(t,inputname(1));
