addpath(pwd)
cd core
addpath(pwd)
cd ..
cd exp
addpath(pwd)
cd ..
cd cross
addpath(pwd)
cd ..
cd fmex
addpath(pwd)
cd ..
cd misc
addpath(pwd)
cd ..
cd solve
addpath(pwd)
cd ..


